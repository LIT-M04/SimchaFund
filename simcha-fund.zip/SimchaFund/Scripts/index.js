﻿$(function() {
    $(".new-simcha").on('click', function() {
        $(".modal").modal();
    });

    $('#datepicker').datetimepicker();
});