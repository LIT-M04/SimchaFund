﻿$(function () {
    $(".switch").bootstrapSwitch({
        onText: 'Yes',
        offText: 'No'
    });
})